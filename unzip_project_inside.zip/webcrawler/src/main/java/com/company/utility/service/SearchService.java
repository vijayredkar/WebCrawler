package com.company.utility.service;

/*
 * Strategy design pattern to implement different search approaches
 * Follows OCP design principle 
 * Decouples client from concrete class implementations 
 */
public interface SearchService 
{
 public void search(String url);
}
