package com.company.utility.service;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.utility.constants.ProjectConstants;
import com.company.utility.controller.SearchController;


/*
 * Using Strategy design pattern.
 * Client can dynamically instantiate the specific search algorithm that best fits it's needs
 * 
 */
@Service
public class WebCrawlerSearch implements SearchService 
{	
	  Logger logger = LoggerFactory.getLogger(SearchController.class);
	  private Set<String> pagesVisited = new HashSet<String>();//store the pages visited uniquely so that we don't revisit
	  private List<String> pagesToVisit = new LinkedList<String>();	//pages yet to be visited
		
	  @Override
	  public void search(String url)
	  {
	      while(this.pagesVisited.size() < ProjectConstants.MAX_PAGES_TO_SEARCH)
	      {
	          String currentUrl;
	          if(this.pagesToVisit.isEmpty())
	          {
	              currentUrl = url;
	              this.pagesVisited.add(url);
	          }
	          else
	          {
	              currentUrl = this.nextUrl();
	          }
	          Crawler crawler = new Crawler();
	          crawler.crawl(currentUrl);
	          this.pagesToVisit.addAll(crawler.getLinks());
	      }
	  }
	  /**
	   * API to keep track of next page to visit
	   */
	  private String nextUrl()
	  {
	      String nextUrl;
	      do
	      {
	          nextUrl = this.pagesToVisit.remove(0);
	      } while(this.pagesVisited.contains(nextUrl));
	      this.pagesVisited.add(nextUrl);
	      return nextUrl;
	  }
	  
	public List<String> getPagesToVisit() 
	{
		return pagesToVisit;
	}
}
