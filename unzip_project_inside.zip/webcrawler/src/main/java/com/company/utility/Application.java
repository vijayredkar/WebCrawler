package com.company.utility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.company.utility.constants.ProjectConstants;
import com.company.utility.controller.SearchController;


/**
 * Bootstrapping application
 *
 */
@SpringBootApplication
public class Application
{
	@Autowired
	SearchController searchController;
	
    public static void main(String[] args)
    {
    	SpringApplication.run(Application.class, args);    	
    	SearchController.process(ProjectConstants.OPERATION_SEARCH_WEBCRAWLER, ProjectConstants.DOMAIN_URL);
    }
}

