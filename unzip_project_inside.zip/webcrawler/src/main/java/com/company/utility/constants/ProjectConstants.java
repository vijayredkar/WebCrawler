package com.company.utility.constants;

public class ProjectConstants
{
  public static final String OPERATION_SEARCH_WEBCRAWLER = "webcrawl";
  public static final String DOMAIN_URL = "http://wiprodigital.com";  
  public static final int    MAX_PAGES_TO_SEARCH = 10;
}
