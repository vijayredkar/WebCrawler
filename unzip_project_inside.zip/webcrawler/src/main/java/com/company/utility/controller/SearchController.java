package com.company.utility.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.company.utility.constants.ProjectConstants;
import com.company.utility.service.SearchService;
import com.company.utility.service.WebCrawlerSearch;

/*
 * Controller to route client requests appropriately to the service methods 
 * Follows FrontController design pattern
 */
@Controller
public class SearchController 
{	
	
 /*
  * API determines which service method should be called	
  */
 public static void process(String operation, String url)
 { 
	Logger logger = LoggerFactory.getLogger(SearchController.class);
	 
	switch (operation) 
	{
		case ProjectConstants.OPERATION_SEARCH_WEBCRAWLER:
			SearchService searchService = new WebCrawlerSearch();
			searchService.search(url);			
			break;
		default:
			logger.info("Invalid operation submitted");
			break;
	}
 }
}
