package com.company.utility.exception;

public class ApplicationException extends Exception 
{
  public ApplicationException(String message) 
  {
	 super(message);
  }
}
