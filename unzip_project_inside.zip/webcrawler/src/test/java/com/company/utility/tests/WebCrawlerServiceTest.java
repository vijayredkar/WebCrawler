package com.company.utility.tests;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.company.utility.constants.ProjectConstants;
import com.company.utility.service.Crawler;
import com.company.utility.service.SearchService;
import com.company.utility.service.WebCrawlerSearch;

public class WebCrawlerServiceTest 
{
	
  @Mock
  Crawler crawler;
  
  
  
  @Before
  public void setUp()
  {
	MockitoAnnotations.initMocks(this);
  }

  @After
  public void tearDown()
  { 
	  
  }
	
  @Test
  public void search()
  {
	  Mockito.when(crawler.crawl(Mockito.anyString())).thenReturn(true);
	  Mockito.when(crawler.getLinks()).thenReturn(Mockito.anyList());
	  
	  WebCrawlerSearch wc = new WebCrawlerSearch();	  
	  wc.search("http://wiprodigital.com");
	  
	  Assert.assertTrue(wc.getPagesToVisit().size()>0);
  }	
}

